class Postava:
    def __init__(self, jmeno ,zivoty, sila, misto):
        self.jmeno=jmeno
        self.zivoty=zivoty
        self.sila=sila
        self.misto=misto
        